-- ============================================
-- FMCG SILVER LAYER - SCD TYPE 2 WITH STREAMS + TASKS
-- 7 BRONZE STREAMS | 7 SILVER SCD2 TABLES | 1 GENERIC PROCEDURE | 7-TASK DAG
-- ============================================
--
-- FLOW
--   S3 -> (COPY / Snowpipe) -> BRONZE table
--      -> STREAM on Bronze (captures only NEW rows)
--      -> TASK calls SP_SCD2_LOAD
--           1. Move stream rows into a staging table (this consumes the stream)
--           2. PREP VIEW: type conversion + validation + FK checks + dedup + ROW_HASH
--           3. Log REJECT / DUPLICATE / STALE rows to SILVER_DQ_EXCEPTIONS
--           4. SCD2: expire changed current rows (IS_CURRENT = FALSE, EFFECTIVE_TO set)
--           5. SCD2: insert new keys + new versions (IS_CURRENT = TRUE)
--           6. Write batch counts to SILVER_LOAD_AUDIT
--      -> SILVER table (full history; use IS_CURRENT = TRUE for latest)
--
-- SCD2 RULES
--   New key                          -> insert version 1
--   Same key, attributes changed     -> close old version, insert new version
--   Same key, same attributes        -> skipped  (idempotent: replay creates nothing)
--   Same key, older than current     -> skipped + logged as STALE
--
-- RUN ORDER: sections 1 -> 9 once. After that the tasks run automatically.
--
-- !! IMPORTANT
--   * This REPLACES the SILVER_* tables created by the previous CTE script.
--   * Do NOT re-run "CREATE OR REPLACE TABLE BRONZE_..." after this.
--     Recreating a Bronze table breaks its stream.
--   * Change COMPUTE_WH (section 8) to your warehouse name.
-- ============================================


USE ROLE ACCOUNTADMIN;

USE DATABASE FMCG_DB;

CREATE OR REPLACE SCHEMA FMCG_DB.SILVER;

USE SCHEMA FMCG_DB.SILVER;


-- ============================================
-- 1. HELPER FUNCTIONS
-- ============================================

CREATE OR REPLACE FUNCTION FMCG_DB.SILVER.TO_TS_ANY(S VARCHAR)
RETURNS TIMESTAMP_NTZ
AS
$$
    COALESCE(
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY-MM-DD HH24:MI:SS.FF'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY-MM-DD HH24:MI:SS'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY/MM/DD HH24:MI:SS'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'MM/DD/YYYY HH24:MI:SS.FF'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'MM/DD/YYYY HH24:MI:SS'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY-MM-DD'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'YYYY/MM/DD'),
        TRY_TO_TIMESTAMP_NTZ(TRIM(S), 'MM/DD/YYYY')
    )
$$;

CREATE OR REPLACE FUNCTION FMCG_DB.SILVER.TO_DATE_ANY(S VARCHAR)
RETURNS DATE
AS
$$
    NULLIF(TO_DATE(FMCG_DB.SILVER.TO_TS_ANY(S)), '9999-12-31'::DATE)
$$;

CREATE OR REPLACE FUNCTION FMCG_DB.SILVER.TO_FLAG(S VARCHAR)
RETURNS VARCHAR(1)
AS
$$
    CASE
        WHEN UPPER(TRIM(S)) IN ('Y','YES','TRUE','T','1') THEN 'Y'
        WHEN UPPER(TRIM(S)) IN ('N','NO','FALSE','F','0') THEN 'N'
    END
$$;


-- ============================================
-- 2. DQ EXCEPTION + LOAD AUDIT TABLES
-- ============================================

CREATE OR REPLACE TABLE SILVER_DQ_EXCEPTIONS (
    RUN_ID         VARCHAR(100),
    TABLE_NAME     VARCHAR(100),
    RECORD_KEY     VARCHAR(20),
    ISSUE_TYPE     VARCHAR(20),          -- REJECT / DUPLICATE / STALE
    ISSUE_REASON   VARCHAR(1000),
    RECORD_DATA    VARIANT,
    LOGGED_AT      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
);

-- One row per table per task run -> reconciliation evidence
-- STAGED = REJECTED + DUPLICATES + STALE + INSERTED + UNCHANGED
CREATE OR REPLACE TABLE SILVER_LOAD_AUDIT (
    RUN_ID         VARCHAR(100),
    TABLE_NAME     VARCHAR(100),
    RUN_TS         TIMESTAMP_NTZ,
    STAGED         NUMBER(10,0),
    REJECTED       NUMBER(10,0),
    DUPLICATES     NUMBER(10,0),
    STALE          NUMBER(10,0),
    EXPIRED        NUMBER(10,0),         -- old versions closed
    INSERTED       NUMBER(10,0),         -- new keys + new versions
    UNCHANGED      NUMBER(10,0),         -- identical replays skipped
    STATUS         VARCHAR(1000)
);


-- ============================================
-- 3. STAGING TABLES
-- Same structure as Bronze. Hold one stream batch at a time.
-- ============================================

CREATE TRANSIENT TABLE IF NOT EXISTS STG_PRODUCTS_RAW             LIKE FMCG_DB.BRONZE.BRONZE_PRODUCTS;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_STORES_RAW               LIKE FMCG_DB.BRONZE.BRONZE_STORES;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_WAREHOUSE_RAW            LIKE FMCG_DB.BRONZE.BRONZE_WAREHOUSE;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_SALES_ORDERS_RAW         LIKE FMCG_DB.BRONZE.BRONZE_SALES_ORDERS;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_INVENTORY_SNAPSHOTS_RAW  LIKE FMCG_DB.BRONZE.BRONZE_INVENTORY_SNAPSHOTS;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_REPLENISHMENT_ORDERS_RAW LIKE FMCG_DB.BRONZE.BRONZE_REPLENISHMENT_ORDERS;
CREATE TRANSIENT TABLE IF NOT EXISTS STG_SALES_EVENTS_RAW         LIKE FMCG_DB.BRONZE.BRONZE_SALES_EVENTS;


-- ============================================
-- 4. SILVER SCD2 TABLES
-- Every table has the same SCD2 / audit columns:
--   <X>_SK          surrogate key (one per version)
--   ROW_HASH        hash of business attributes (change detection)
--   VERSION_TS      source version time (SOURCE_UPDATED_TS, else Bronze load time)
--   EFFECTIVE_FROM  version valid from
--   EFFECTIVE_TO    version valid to (9999-12-31 for current)
--   IS_CURRENT      TRUE for the latest version
-- ============================================

CREATE OR REPLACE TABLE SILVER_PRODUCTS (
    PRODUCT_SK          NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    PRODUCT_ID          VARCHAR(20)   NOT NULL,
    PRODUCT_NAME        VARCHAR(100),
    CATEGORY            VARCHAR(100),
    SUB_CATEGORY        VARCHAR(100),
    BRAND               VARCHAR(100),
    UNIT_COST           NUMBER(18,2),
    LIST_PRICE          NUMBER(18,2),
    SHELF_LIFE_DAYS     NUMBER(10,0),
    PACK_SIZE           NUMBER(10,0),
    ACTIVE_FLAG         VARCHAR(1),
    SOURCE_UPDATED_TS   TIMESTAMP_NTZ,
    ROW_HASH            NUMBER(19,0),
    VERSION_TS          TIMESTAMP_NTZ,
    EFFECTIVE_FROM      TIMESTAMP_NTZ,
    EFFECTIVE_TO        TIMESTAMP_NTZ,
    IS_CURRENT          BOOLEAN,
    DQ_STATUS           VARCHAR(20),
    DQ_REASON           VARCHAR(1000),
    SOURCE_FILE         VARCHAR(500),
    BATCH_ID            VARCHAR(100),
    BRONZE_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_UPDATED_TS   TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_PRODUCTS PRIMARY KEY (PRODUCT_SK)
);

CREATE OR REPLACE TABLE SILVER_STORES (
    STORE_SK                NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    STORE_ID                VARCHAR(20)  NOT NULL,
    STORE_NAME              VARCHAR(100),
    CITY                    VARCHAR(100),
    STATE                   VARCHAR(100),
    REGION                  VARCHAR(100),
    STORE_FORMAT            VARCHAR(100),
    OPENING_DATE            DATE,
    STORAGE_CAPACITY_UNITS  NUMBER(10,0),
    ACTIVE_FLAG             VARCHAR(1),
    SOURCE_UPDATED_TS       TIMESTAMP_NTZ,
    ROW_HASH                NUMBER(19,0),
    VERSION_TS              TIMESTAMP_NTZ,
    EFFECTIVE_FROM          TIMESTAMP_NTZ,
    EFFECTIVE_TO            TIMESTAMP_NTZ,
    IS_CURRENT              BOOLEAN,
    DQ_STATUS               VARCHAR(20),
    DQ_REASON               VARCHAR(1000),
    SOURCE_FILE             VARCHAR(500),
    BATCH_ID                VARCHAR(100),
    BRONZE_LOAD_TS          TIMESTAMP_NTZ,
    SILVER_LOAD_TS          TIMESTAMP_NTZ,
    SILVER_UPDATED_TS       TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_STORES PRIMARY KEY (STORE_SK)
);

CREATE OR REPLACE TABLE SILVER_WAREHOUSE (
    WAREHOUSE_SK              NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    WAREHOUSE_ID              VARCHAR(20)  NOT NULL,
    WAREHOUSE_NAME            VARCHAR(100),
    CITY                      VARCHAR(100),
    STATE                     VARCHAR(100),
    REGION                    VARCHAR(100),
    WAREHOUSE_TYPE            VARCHAR(100),
    CAPACITY_UNITS            NUMBER(10,0),
    TEMPERATURE_CONTROL_FLAG  VARCHAR(1),
    ACTIVE_FLAG               VARCHAR(1),
    SOURCE_UPDATED_TS         TIMESTAMP_NTZ,
    ROW_HASH                  NUMBER(19,0),
    VERSION_TS                TIMESTAMP_NTZ,
    EFFECTIVE_FROM            TIMESTAMP_NTZ,
    EFFECTIVE_TO              TIMESTAMP_NTZ,
    IS_CURRENT                BOOLEAN,
    DQ_STATUS                 VARCHAR(20),
    DQ_REASON                 VARCHAR(1000),
    SOURCE_FILE               VARCHAR(500),
    BATCH_ID                  VARCHAR(100),
    BRONZE_LOAD_TS            TIMESTAMP_NTZ,
    SILVER_LOAD_TS            TIMESTAMP_NTZ,
    SILVER_UPDATED_TS         TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_WAREHOUSE PRIMARY KEY (WAREHOUSE_SK)
);

CREATE OR REPLACE TABLE SILVER_SALES_ORDERS (
    SALES_ORDER_SK      NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    ORDER_ID            VARCHAR(20)  NOT NULL,
    STORE_ID            VARCHAR(20),
    PRODUCT_ID          VARCHAR(20),
    ORDER_DATE          DATE,
    QUANTITY_SOLD       NUMBER(10,0),
    UNIT_PRICE          NUMBER(18,2),
    DISCOUNT_AMOUNT     NUMBER(18,2),
    TAX_AMOUNT          NUMBER(18,2),
    NET_AMOUNT          NUMBER(18,2),
    ORDER_STATUS        VARCHAR(20),
    SALES_CHANNEL       VARCHAR(20),
    SOURCE_UPDATED_TS   TIMESTAMP_NTZ,
    ROW_HASH            NUMBER(19,0),
    VERSION_TS          TIMESTAMP_NTZ,
    EFFECTIVE_FROM      TIMESTAMP_NTZ,
    EFFECTIVE_TO        TIMESTAMP_NTZ,
    IS_CURRENT          BOOLEAN,
    DQ_STATUS           VARCHAR(20),
    DQ_REASON           VARCHAR(1000),
    SOURCE_FILE         VARCHAR(500),
    BATCH_ID            VARCHAR(100),
    BRONZE_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_UPDATED_TS   TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_SALES_ORDERS PRIMARY KEY (SALES_ORDER_SK)
);

CREATE OR REPLACE TABLE SILVER_INVENTORY_SNAPSHOTS (
    SNAPSHOT_SK         NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    SNAPSHOT_ID         VARCHAR(20)  NOT NULL,
    LOCATION_TYPE       VARCHAR(20),
    LOCATION_ID         VARCHAR(20),
    PRODUCT_ID          VARCHAR(20),
    STOCK_STATUS        VARCHAR(20),
    SNAPSHOT_DATE       DATE,
    SOURCE_UPDATED_TS   TIMESTAMP_NTZ,
    ON_HAND_QTY         NUMBER(10,0),
    RESERVED_QTY        NUMBER(10,0),
    AVAILABLE_QTY       NUMBER(10,0),
    REORDER_POINT       NUMBER(10,0),
    SAFETY_STOCK        NUMBER(10,0),
    ROW_HASH            NUMBER(19,0),
    VERSION_TS          TIMESTAMP_NTZ,
    EFFECTIVE_FROM      TIMESTAMP_NTZ,
    EFFECTIVE_TO        TIMESTAMP_NTZ,
    IS_CURRENT          BOOLEAN,
    DQ_STATUS           VARCHAR(20),
    DQ_REASON           VARCHAR(1000),
    SOURCE_FILE         VARCHAR(500),
    BATCH_ID            VARCHAR(100),
    BRONZE_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_LOAD_TS      TIMESTAMP_NTZ,
    SILVER_UPDATED_TS   TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_INVENTORY PRIMARY KEY (SNAPSHOT_SK)
);

CREATE OR REPLACE TABLE SILVER_REPLENISHMENT_ORDERS (
    REPLENISHMENT_SK        NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    REPLENISHMENT_ID        VARCHAR(20)  NOT NULL,
    SOURCE_WAREHOUSE_ID     VARCHAR(20),
    DESTINATION_STORE_ID    VARCHAR(20),
    PRODUCT_ID              VARCHAR(20),
    REQUEST_DATE            DATE,
    ALLOCATED_DATE          DATE,
    DISPATCH_DATE           DATE,
    DELIVERED_DATE          DATE,
    REPLENISHMENT_STATUS    VARCHAR(20),
    PRIORITY_CODE           VARCHAR(20),
    REQUEST_QTY             NUMBER(10,0),
    ALLOCATED_QTY           NUMBER(10,0),
    DISPATCH_QTY            NUMBER(10,0),
    DELIVERED_QTY           NUMBER(10,0),
    EXPECTED_DELIVERY_DATE  DATE,
    SOURCE_UPDATED_TS       TIMESTAMP_NTZ,
    ROW_HASH                NUMBER(19,0),
    VERSION_TS              TIMESTAMP_NTZ,
    EFFECTIVE_FROM          TIMESTAMP_NTZ,
    EFFECTIVE_TO            TIMESTAMP_NTZ,
    IS_CURRENT              BOOLEAN,
    DQ_STATUS               VARCHAR(20),
    DQ_REASON               VARCHAR(1000),
    SOURCE_FILE             VARCHAR(500),
    BATCH_ID                VARCHAR(100),
    BRONZE_LOAD_TS          TIMESTAMP_NTZ,
    SILVER_LOAD_TS          TIMESTAMP_NTZ,
    SILVER_UPDATED_TS       TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_REPLENISHMENT PRIMARY KEY (REPLENISHMENT_SK)
);

CREATE OR REPLACE TABLE SILVER_SALES_EVENTS (
    SALES_EVENT_SK    NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    EVENT_ID          VARCHAR(20)  NOT NULL,
    STORE_ID          VARCHAR(20),
    PRODUCT_ID        VARCHAR(20),
    EVENT_TIMESTAMP   TIMESTAMP_NTZ,
    EVENT_DATE        DATE,
    SALES_CHANNEL     VARCHAR(20),
    QUANTITY          NUMBER(10,0),
    SELLING_PRICE     NUMBER(18,2),
    PROMOTION_FLAG    VARCHAR(1),
    PROMOTION_ID      VARCHAR(20),
    WEATHER_CODE      VARCHAR(20),
    SOURCE_SYSTEM     VARCHAR(100),
    TERMINAL_ID       VARCHAR(20),
    BASKET_SIZE       NUMBER(10,0),
    PAYMENT_MODE      VARCHAR(20),
    ROW_HASH          NUMBER(19,0),
    VERSION_TS        TIMESTAMP_NTZ,
    EFFECTIVE_FROM    TIMESTAMP_NTZ,
    EFFECTIVE_TO      TIMESTAMP_NTZ,
    IS_CURRENT        BOOLEAN,
    DQ_STATUS         VARCHAR(20),
    DQ_REASON         VARCHAR(1000),
    SOURCE_FILE       VARCHAR(500),
    BATCH_ID          VARCHAR(100),
    BRONZE_LOAD_TS    TIMESTAMP_NTZ,
    SILVER_LOAD_TS    TIMESTAMP_NTZ,
    SILVER_UPDATED_TS TIMESTAMP_NTZ,
    CONSTRAINT PK_SILVER_SALES_EVENTS PRIMARY KEY (SALES_EVENT_SK)
);


-- ============================================
-- 5. PREP VIEWS (over the staging tables)
-- Type conversion + validation + FK check + dedup + ROW_HASH.
-- Every view returns the same control columns:
--   BK, VERSION_TS, ROW_HASH, REJECT_REASON, DQ_STATUS, DQ_REASON, RN
-- ============================================

-- 5.1 PRODUCTS
CREATE OR REPLACE VIEW V_PREP_PRODUCTS AS
WITH typed AS (
    SELECT
        UPPER(TRIM(PRODUCT_ID))                         AS PRODUCT_ID,
        TRIM(PRODUCT_NAME)                              AS PRODUCT_NAME,
        TRIM(CATEGORY)                                  AS CATEGORY,
        TRIM(SUB_CATEGORY)                              AS SUB_CATEGORY,
        TRIM(BRAND)                                     AS BRAND,
        TRY_TO_NUMBER(TRIM(UNIT_COST), 18, 2)           AS UNIT_COST,
        TRY_TO_NUMBER(TRIM(LIST_PRICE), 18, 2)          AS LIST_PRICE,
        TRY_TO_NUMBER(TRIM(SHELF_LIFE_DAYS))            AS SHELF_LIFE_DAYS,
        TRY_TO_NUMBER(TRIM(PACK_SIZE))                  AS PACK_SIZE,
        FMCG_DB.SILVER.TO_FLAG(ACTIVE_FLAG)             AS ACTIVE_FLAG,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)     AS SOURCE_UPDATED_TS,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)        AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_PRODUCTS_RAW
),
checked AS (
    SELECT t.*,
        PRODUCT_ID                                                   AS BK,
        COALESCE(SOURCE_UPDATED_TS, BRONZE_LOAD_TS)                  AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(PRODUCT_ID IS NULL,                    'Missing PRODUCT_ID', NULL),
            IFF(UNIT_COST  IS NULL OR UNIT_COST  < 0,  'Invalid UNIT_COST',  NULL),
            IFF(LIST_PRICE IS NULL OR LIST_PRICE < 0,  'Invalid LIST_PRICE', NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(LIST_PRICE < UNIT_COST,                'List price below unit cost', NULL),
            IFF(SHELF_LIFE_DAYS IS NULL,               'Missing shelf life',         NULL),
            IFF(PACK_SIZE IS NULL,                     'Missing pack size',          NULL),
            IFF(ACTIVE_FLAG IS NULL,                   'Unknown active flag',        NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
)
SELECT c.*,
    HASH(PRODUCT_NAME, CATEGORY, SUB_CATEGORY, BRAND, UNIT_COST, LIST_PRICE,
         SHELF_LIFE_DAYS, PACK_SIZE, ACTIVE_FLAG)                    AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.2 STORES
CREATE OR REPLACE VIEW V_PREP_STORES AS
WITH typed AS (
    SELECT
        UPPER(TRIM(STORE_ID))                           AS STORE_ID,
        TRIM(STORE_NAME)                                AS STORE_NAME,
        TRIM(CITY)                                      AS CITY,
        TRIM(STATE)                                     AS STATE,
        UPPER(TRIM(REGION))                             AS REGION,
        TRIM(STORE_FORMAT)                              AS STORE_FORMAT,
        FMCG_DB.SILVER.TO_DATE_ANY(OPENING_DATE)        AS OPENING_DATE,
        TRY_TO_NUMBER(TRIM(STORAGE_CAPACITY_UNITS))     AS STORAGE_CAPACITY_UNITS,
        FMCG_DB.SILVER.TO_FLAG(ACTIVE_FLAG)             AS ACTIVE_FLAG,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)     AS SOURCE_UPDATED_TS,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)        AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_STORES_RAW
),
checked AS (
    SELECT t.*,
        STORE_ID                                                     AS BK,
        COALESCE(SOURCE_UPDATED_TS, BRONZE_LOAD_TS)                  AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(STORE_ID IS NULL,                  'Missing STORE_ID',          NULL),
            IFF(STORAGE_CAPACITY_UNITS < 0,        'Negative storage capacity', NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(OPENING_DATE IS NULL,              'Missing opening date',      NULL),
            IFF(OPENING_DATE > CURRENT_DATE(),     'Opening date in future',    NULL),
            IFF(STORAGE_CAPACITY_UNITS IS NULL,    'Missing storage capacity',  NULL),
            IFF(ACTIVE_FLAG IS NULL,               'Unknown active flag',       NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
)
SELECT c.*,
    HASH(STORE_NAME, CITY, STATE, REGION, STORE_FORMAT, OPENING_DATE,
         STORAGE_CAPACITY_UNITS, ACTIVE_FLAG)                        AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.3 WAREHOUSE (IDMC O_* port columns are ignored)
CREATE OR REPLACE VIEW V_PREP_WAREHOUSE AS
WITH typed AS (
    SELECT
        UPPER(TRIM(WAREHOUSE_ID))                         AS WAREHOUSE_ID,
        TRIM(WAREHOUSE_NAME)                              AS WAREHOUSE_NAME,
        TRIM(CITY)                                        AS CITY,
        TRIM(STATE)                                       AS STATE,
        UPPER(TRIM(REGION))                               AS REGION,
        TRIM(WAREHOUSE_TYPE)                              AS WAREHOUSE_TYPE,
        TRY_TO_NUMBER(TRIM(CAPACITY_UNITS))               AS CAPACITY_UNITS,
        FMCG_DB.SILVER.TO_FLAG(TEMPERATURE_CONTROL_FLAG)  AS TEMPERATURE_CONTROL_FLAG,
        FMCG_DB.SILVER.TO_FLAG(ACTIVE_FLAG)               AS ACTIVE_FLAG,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)       AS SOURCE_UPDATED_TS,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)          AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_WAREHOUSE_RAW
),
checked AS (
    SELECT t.*,
        WAREHOUSE_ID                                                 AS BK,
        COALESCE(SOURCE_UPDATED_TS, BRONZE_LOAD_TS)                  AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(WAREHOUSE_ID IS NULL,             'Missing WAREHOUSE_ID', NULL),
            IFF(CAPACITY_UNITS < 0,               'Negative capacity',    NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(CAPACITY_UNITS IS NULL,           'Missing capacity',          NULL),
            IFF(TEMPERATURE_CONTROL_FLAG IS NULL, 'Unknown temp-control flag', NULL),
            IFF(ACTIVE_FLAG IS NULL,              'Unknown active flag',       NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
)
SELECT c.*,
    HASH(WAREHOUSE_NAME, CITY, STATE, REGION, WAREHOUSE_TYPE, CAPACITY_UNITS,
         TEMPERATURE_CONTROL_FLAG, ACTIVE_FLAG)                      AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.4 SALES ORDERS  (FK -> current stores, current products)
CREATE OR REPLACE VIEW V_PREP_SALES_ORDERS AS
WITH typed AS (
    SELECT
        UPPER(TRIM(ORDER_ID))                           AS ORDER_ID,
        UPPER(TRIM(STORE_ID))                           AS STORE_ID,
        UPPER(TRIM(PRODUCT_ID))                         AS PRODUCT_ID,
        FMCG_DB.SILVER.TO_DATE_ANY(ORDER_DATE)          AS ORDER_DATE,
        TRY_TO_NUMBER(TRIM(QUANTITY_SOLD))              AS QUANTITY_SOLD,
        TRY_TO_NUMBER(TRIM(UNIT_PRICE), 18, 2)          AS UNIT_PRICE,
        TRY_TO_NUMBER(TRIM(DISCOUNT_AMOUNT), 18, 2)     AS DISCOUNT_AMOUNT,
        TRY_TO_NUMBER(TRIM(TAX_AMOUNT), 18, 2)          AS TAX_AMOUNT,
        TRY_TO_NUMBER(TRIM(NET_AMOUNT), 18, 2)          AS NET_AMOUNT,
        UPPER(TRIM(ORDER_STATUS))                       AS ORDER_STATUS,
        UPPER(TRIM(SALES_CHANNEL))                      AS SALES_CHANNEL,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)     AS SOURCE_UPDATED_TS,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)        AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_SALES_ORDERS_RAW
),
checked AS (
    SELECT t.*,
        t.ORDER_ID                                                   AS BK,
        COALESCE(t.SOURCE_UPDATED_TS, t.BRONZE_LOAD_TS)              AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.ORDER_ID IS NULL,                              'Missing ORDER_ID',                 NULL),
            IFF(t.ORDER_DATE IS NULL,                            'Invalid/missing ORDER_DATE',       NULL),
            IFF(t.QUANTITY_SOLD IS NULL OR t.QUANTITY_SOLD <= 0, 'Invalid QUANTITY_SOLD',            NULL),
            IFF(t.UNIT_PRICE IS NULL OR t.UNIT_PRICE < 0,        'Invalid UNIT_PRICE',               NULL),
            IFF(s.STORE_ID IS NULL,                              'STORE_ID not found in stores',     NULL),
            IFF(p.PRODUCT_ID IS NULL,                            'PRODUCT_ID not found in products', NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.DISCOUNT_AMOUNT IS NULL,                       'Missing discount',            NULL),
            IFF(t.DISCOUNT_AMOUNT < 0,                           'Negative discount',           NULL),
            IFF(t.TAX_AMOUNT IS NULL,                            'Missing tax',                 NULL),
            IFF(t.NET_AMOUNT IS NULL OR t.NET_AMOUNT < 0,        'Missing/negative net amount', NULL),
            IFF(t.ORDER_DATE > CURRENT_DATE(),                   'Order date in future',        NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
    LEFT JOIN (SELECT DISTINCT STORE_ID   FROM FMCG_DB.SILVER.SILVER_STORES   WHERE IS_CURRENT) s
           ON s.STORE_ID = t.STORE_ID
    LEFT JOIN (SELECT DISTINCT PRODUCT_ID FROM FMCG_DB.SILVER.SILVER_PRODUCTS WHERE IS_CURRENT) p
           ON p.PRODUCT_ID = t.PRODUCT_ID
)
SELECT c.*,
    HASH(STORE_ID, PRODUCT_ID, ORDER_DATE, QUANTITY_SOLD, UNIT_PRICE, DISCOUNT_AMOUNT,
         TAX_AMOUNT, NET_AMOUNT, ORDER_STATUS, SALES_CHANNEL)        AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.5 INVENTORY SNAPSHOTS  (FK -> current products, current stores / warehouses)
CREATE OR REPLACE VIEW V_PREP_INVENTORY_SNAPSHOTS AS
WITH typed AS (
    SELECT
        UPPER(TRIM(SNAPSHOT_ID))                        AS SNAPSHOT_ID,
        UPPER(TRIM(LOCATION_TYPE))                      AS LOCATION_TYPE,
        UPPER(TRIM(LOCATION_ID))                        AS LOCATION_ID,
        UPPER(TRIM(PRODUCT_ID))                         AS PRODUCT_ID,
        UPPER(TRIM(STOCK_STATUS))                       AS STOCK_STATUS,
        FMCG_DB.SILVER.TO_DATE_ANY(SNAPSHOT_DATE)       AS SNAPSHOT_DATE,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)     AS SOURCE_UPDATED_TS,
        TRY_TO_NUMBER(TRIM(ON_HAND_QTY))                AS ON_HAND_QTY,
        TRY_TO_NUMBER(TRIM(RESERVED_QTY))               AS RESERVED_QTY,
        TRY_TO_NUMBER(TRIM(AVAILABLE_QTY))              AS AVAILABLE_QTY,
        TRY_TO_NUMBER(TRIM(REORDER_POINT))              AS REORDER_POINT,
        TRY_TO_NUMBER(TRIM(SAFETY_STOCK))               AS SAFETY_STOCK,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)        AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_INVENTORY_SNAPSHOTS_RAW
),
checked AS (
    SELECT t.*,
        t.SNAPSHOT_ID                                                AS BK,
        COALESCE(t.SOURCE_UPDATED_TS, t.BRONZE_LOAD_TS)              AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.SNAPSHOT_ID IS NULL,                         'Missing SNAPSHOT_ID',              NULL),
            IFF(t.SNAPSHOT_DATE IS NULL,                       'Invalid/missing SNAPSHOT_DATE',    NULL),
            IFF(t.ON_HAND_QTY IS NULL OR t.ON_HAND_QTY < 0,    'Invalid ON_HAND_QTY',              NULL),
            IFF(t.RESERVED_QTY < 0,                            'Negative RESERVED_QTY',            NULL),
            IFF(p.PRODUCT_ID IS NULL,                          'PRODUCT_ID not found in products', NULL),
            IFF(s.STORE_ID IS NULL AND w.WAREHOUSE_ID IS NULL, 'LOCATION_ID not found in stores/warehouse', NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.RESERVED_QTY > t.ON_HAND_QTY,                'Reserved exceeds on-hand',         NULL),
            IFF(t.AVAILABLE_QTY <> t.ON_HAND_QTY - t.RESERVED_QTY, 'Available <> on-hand - reserved', NULL),
            IFF(t.REORDER_POINT IS NULL,                       'Missing reorder point',            NULL),
            IFF(t.SAFETY_STOCK IS NULL,                        'Missing safety stock',             NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
    LEFT JOIN (SELECT DISTINCT PRODUCT_ID   FROM FMCG_DB.SILVER.SILVER_PRODUCTS  WHERE IS_CURRENT) p
           ON p.PRODUCT_ID = t.PRODUCT_ID
    LEFT JOIN (SELECT DISTINCT STORE_ID     FROM FMCG_DB.SILVER.SILVER_STORES    WHERE IS_CURRENT) s
           ON s.STORE_ID = t.LOCATION_ID
    LEFT JOIN (SELECT DISTINCT WAREHOUSE_ID FROM FMCG_DB.SILVER.SILVER_WAREHOUSE WHERE IS_CURRENT) w
           ON w.WAREHOUSE_ID = t.LOCATION_ID
)
SELECT c.*,
    HASH(LOCATION_TYPE, LOCATION_ID, PRODUCT_ID, STOCK_STATUS, SNAPSHOT_DATE, ON_HAND_QTY,
         RESERVED_QTY, AVAILABLE_QTY, REORDER_POINT, SAFETY_STOCK)   AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.6 REPLENISHMENT ORDERS  (FK -> current warehouse, stores, products)
CREATE OR REPLACE VIEW V_PREP_REPLENISHMENT_ORDERS AS
WITH typed AS (
    SELECT
        UPPER(TRIM(REPLENISHMENT_ID))                       AS REPLENISHMENT_ID,
        UPPER(TRIM(SOURCE_WAREHOUSE_ID))                    AS SOURCE_WAREHOUSE_ID,
        UPPER(TRIM(DESTINATION_STORE_ID))                   AS DESTINATION_STORE_ID,
        UPPER(TRIM(PRODUCT_ID))                             AS PRODUCT_ID,
        FMCG_DB.SILVER.TO_DATE_ANY(REQUEST_DATE)            AS REQUEST_DATE,
        FMCG_DB.SILVER.TO_DATE_ANY(ALLOCATED_DATE)          AS ALLOCATED_DATE,
        FMCG_DB.SILVER.TO_DATE_ANY(DISPATCH_DATE)           AS DISPATCH_DATE,
        FMCG_DB.SILVER.TO_DATE_ANY(DELIVERED_DATE)          AS DELIVERED_DATE,
        UPPER(TRIM(REPLENISHMENT_STATUS))                   AS REPLENISHMENT_STATUS,
        UPPER(TRIM(PRIORITY_CODE))                          AS PRIORITY_CODE,
        TRY_TO_NUMBER(TRIM(REQUEST_QTY))                    AS REQUEST_QTY,
        TRY_TO_NUMBER(TRIM(ALLOCATED_QTY))                  AS ALLOCATED_QTY,
        TRY_TO_NUMBER(TRIM(DISPATCH_QTY))                   AS DISPATCH_QTY,
        TRY_TO_NUMBER(TRIM(DELIVERED_QTY))                  AS DELIVERED_QTY,
        FMCG_DB.SILVER.TO_DATE_ANY(EXPECTED_DELIVERY_DATE)  AS EXPECTED_DELIVERY_DATE,
        FMCG_DB.SILVER.TO_TS_ANY(SOURCE_UPDATED_TS)         AS SOURCE_UPDATED_TS,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)            AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_REPLENISHMENT_ORDERS_RAW
),
checked AS (
    SELECT t.*,
        t.REPLENISHMENT_ID                                           AS BK,
        COALESCE(t.SOURCE_UPDATED_TS, t.BRONZE_LOAD_TS)              AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.REPLENISHMENT_ID IS NULL,                  'Missing REPLENISHMENT_ID',       NULL),
            IFF(t.REQUEST_DATE IS NULL,                      'Invalid/missing REQUEST_DATE',   NULL),
            IFF(t.REQUEST_QTY IS NULL OR t.REQUEST_QTY < 0
                OR t.ALLOCATED_QTY < 0 OR t.DISPATCH_QTY < 0
                OR t.DELIVERED_QTY < 0,                      'Invalid/negative quantity',      NULL),
            IFF(t.ALLOCATED_DATE < t.REQUEST_DATE,           'Allocated before request',       NULL),
            IFF(t.DISPATCH_DATE  < t.REQUEST_DATE,           'Dispatch before request',        NULL),
            IFF(t.DELIVERED_DATE < t.DISPATCH_DATE,          'Delivered before dispatch',      NULL),
            IFF(w.WAREHOUSE_ID IS NULL,                      'SOURCE_WAREHOUSE_ID not found',  NULL),
            IFF(s.STORE_ID     IS NULL,                      'DESTINATION_STORE_ID not found', NULL),
            IFF(p.PRODUCT_ID   IS NULL,                      'PRODUCT_ID not found',           NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.ALLOCATED_QTY > t.REQUEST_QTY,             'Allocated > requested',          NULL),
            IFF(t.DISPATCH_QTY  > t.ALLOCATED_QTY,           'Dispatched > allocated',         NULL),
            IFF(t.DELIVERED_QTY > t.DISPATCH_QTY,            'Delivered > dispatched',         NULL),
            IFF(t.REPLENISHMENT_STATUS = 'DELIVERED' AND t.DELIVERED_DATE IS NULL,
                                                             'DELIVERED status without delivered date', NULL),
            IFF(t.EXPECTED_DELIVERY_DATE IS NULL,            'Missing expected delivery date', NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
    LEFT JOIN (SELECT DISTINCT WAREHOUSE_ID FROM FMCG_DB.SILVER.SILVER_WAREHOUSE WHERE IS_CURRENT) w
           ON w.WAREHOUSE_ID = t.SOURCE_WAREHOUSE_ID
    LEFT JOIN (SELECT DISTINCT STORE_ID     FROM FMCG_DB.SILVER.SILVER_STORES    WHERE IS_CURRENT) s
           ON s.STORE_ID = t.DESTINATION_STORE_ID
    LEFT JOIN (SELECT DISTINCT PRODUCT_ID   FROM FMCG_DB.SILVER.SILVER_PRODUCTS  WHERE IS_CURRENT) p
           ON p.PRODUCT_ID = t.PRODUCT_ID
)
SELECT c.*,
    HASH(SOURCE_WAREHOUSE_ID, DESTINATION_STORE_ID, PRODUCT_ID, REQUEST_DATE, ALLOCATED_DATE,
         DISPATCH_DATE, DELIVERED_DATE, REPLENISHMENT_STATUS, PRIORITY_CODE, REQUEST_QTY,
         ALLOCATED_QTY, DISPATCH_QTY, DELIVERED_QTY, EXPECTED_DELIVERY_DATE) AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- 5.7 SALES EVENTS  (FK -> current stores, current products)
-- No SOURCE_UPDATED_TS in this file -> VERSION_TS = Bronze load time
CREATE OR REPLACE VIEW V_PREP_SALES_EVENTS AS
WITH typed AS (
    SELECT
        UPPER(TRIM(EVENT_ID))                                   AS EVENT_ID,
        UPPER(TRIM(STORE_ID))                                   AS STORE_ID,
        UPPER(TRIM(PRODUCT_ID))                                 AS PRODUCT_ID,
        FMCG_DB.SILVER.TO_TS_ANY(EVENT_TIMESTAMP)               AS EVENT_TIMESTAMP,
        TO_DATE(FMCG_DB.SILVER.TO_TS_ANY(EVENT_TIMESTAMP))      AS EVENT_DATE,
        UPPER(TRIM(SALES_CHANNEL))                              AS SALES_CHANNEL,
        TRY_TO_NUMBER(TRIM(QUANTITY))                           AS QUANTITY,
        TRY_TO_NUMBER(TRIM(SELLING_PRICE), 18, 2)               AS SELLING_PRICE,
        FMCG_DB.SILVER.TO_FLAG(PROMOTION_FLAG)                  AS PROMOTION_FLAG,
        NULLIF(UPPER(TRIM(PROMOTION_ID)), 'NO_PROMOTION')       AS PROMOTION_ID,
        UPPER(TRIM(WEATHER_CODE))                               AS WEATHER_CODE,
        TRIM(SOURCE_SYSTEM)                                     AS SOURCE_SYSTEM,
        UPPER(TRIM(TERMINAL_ID))                                AS TERMINAL_ID,
        TRY_TO_NUMBER(TRIM(BASKET_SIZE))                        AS BASKET_SIZE,
        UPPER(TRIM(PAYMENT_MODE))                               AS PAYMENT_MODE,
        SOURCE_FILE,
        BATCH_ID,
        FMCG_DB.SILVER.TO_TS_ANY(LOAD_TIMESTAMP)                AS BRONZE_LOAD_TS
    FROM FMCG_DB.SILVER.STG_SALES_EVENTS_RAW
),
checked AS (
    SELECT t.*,
        t.EVENT_ID                                                   AS BK,
        t.BRONZE_LOAD_TS                                             AS VERSION_TS,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.EVENT_ID IS NULL,                              'Missing EVENT_ID',                 NULL),
            IFF(t.EVENT_TIMESTAMP IS NULL,                       'Invalid/missing EVENT_TIMESTAMP',  NULL),
            IFF(t.QUANTITY IS NULL OR t.QUANTITY <= 0,           'Invalid QUANTITY',                 NULL),
            IFF(t.SELLING_PRICE IS NULL OR t.SELLING_PRICE < 0,  'Invalid SELLING_PRICE',            NULL),
            IFF(s.STORE_ID IS NULL,                              'STORE_ID not found in stores',     NULL),
            IFF(p.PRODUCT_ID IS NULL,                            'PRODUCT_ID not found in products', NULL)
        ), '; '), '')                                                AS REJECT_REASON,
        NULLIF(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
            IFF(t.PROMOTION_FLAG = 'Y' AND t.PROMOTION_ID IS NULL,     'Promo flag Y without promotion id', NULL),
            IFF(t.PROMOTION_FLAG = 'N' AND t.PROMOTION_ID IS NOT NULL, 'Promotion id with flag N',          NULL),
            IFF(t.WEATHER_CODE IS NULL,                                'Missing weather code',              NULL)
        ), '; '), '')                                                AS DQ_REASON
    FROM typed t
    LEFT JOIN (SELECT DISTINCT STORE_ID   FROM FMCG_DB.SILVER.SILVER_STORES   WHERE IS_CURRENT) s
           ON s.STORE_ID = t.STORE_ID
    LEFT JOIN (SELECT DISTINCT PRODUCT_ID FROM FMCG_DB.SILVER.SILVER_PRODUCTS WHERE IS_CURRENT) p
           ON p.PRODUCT_ID = t.PRODUCT_ID
)
SELECT c.*,
    HASH(STORE_ID, PRODUCT_ID, EVENT_TIMESTAMP, SALES_CHANNEL, QUANTITY, SELLING_PRICE,
         PROMOTION_FLAG, PROMOTION_ID, WEATHER_CODE, SOURCE_SYSTEM, TERMINAL_ID,
         BASKET_SIZE, PAYMENT_MODE)                                  AS ROW_HASH,
    IFF(DQ_REASON IS NULL, 'VALID', 'WARNING')                       AS DQ_STATUS,
    ROW_NUMBER() OVER (PARTITION BY BK
                       ORDER BY IFF(REJECT_REASON IS NULL, 0, 1),
                                VERSION_TS DESC NULLS LAST,
                                BRONZE_LOAD_TS DESC NULLS LAST)      AS RN
FROM checked c;


-- ============================================
-- 6. GENERIC SCD2 LOAD PROCEDURE
-- Runs in ONE transaction: if any step fails, everything rolls back
-- and the stream is NOT consumed, so the batch is retried next run.
-- ============================================

CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_SCD2_LOAD(
    P_ENTITY  VARCHAR,     -- name used in audit / exceptions
    P_STREAM  VARCHAR,     -- Bronze stream
    P_STG     VARCHAR,     -- staging table
    P_VIEW    VARCHAR,     -- prep view
    P_TARGET  VARCHAR,     -- Silver SCD2 table
    P_KEY     VARCHAR,     -- business key column in target
    P_COLS    VARCHAR      -- business columns (same names in view and target)
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_ts        VARCHAR;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id := UUID_STRING();
    v_ts     := TO_VARCHAR(CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'YYYY-MM-DD HH24:MI:SS.FF3');

    BEGIN TRANSACTION;

    -- STEP 1: consume stream into staging (DELETE, not TRUNCATE, to stay inside the transaction)
    EXECUTE IMMEDIATE 'DELETE FROM ' || P_STG;
    EXECUTE IMMEDIATE 'INSERT INTO ' || P_STG ||
        ' SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID) FROM ' || P_STREAM;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN P_ENTITY || ': no new rows';
    END IF;

    -- STEP 2: rejects + in-batch duplicates
    EXECUTE IMMEDIATE
        'INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
             (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
         SELECT ''' || v_run_id || ''', ''' || P_ENTITY || ''', BK,
                IFF(REJECT_REASON IS NOT NULL, ''REJECT'', ''DUPLICATE''),
                COALESCE(REJECT_REASON, ''Duplicate key in batch - older version''),
                OBJECT_CONSTRUCT(*)
         FROM ' || P_VIEW || '
         WHERE RN > 1 OR REJECT_REASON IS NOT NULL';

    -- STEP 3: stale rows (older than the current Silver version)
    EXECUTE IMMEDIATE
        'INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
             (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
         SELECT ''' || v_run_id || ''', ''' || P_ENTITY || ''', s.BK,
                ''STALE'', ''Older than current Silver version - ignored'',
                OBJECT_CONSTRUCT(*)
         FROM ' || P_VIEW || ' s
         WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
           AND EXISTS (SELECT 1 FROM ' || P_TARGET || ' t
                       WHERE t.' || P_KEY || ' = s.BK
                         AND t.IS_CURRENT = TRUE
                         AND t.ROW_HASH <> s.ROW_HASH
                         AND t.VERSION_TS > s.VERSION_TS)';

    -- STEP 4: SCD2 expire - close current version when attributes changed
    EXECUTE IMMEDIATE
        'UPDATE ' || P_TARGET || ' t
         SET IS_CURRENT        = FALSE,
             EFFECTIVE_TO      = s.VERSION_TS,
             SILVER_UPDATED_TS = ''' || v_ts || '''::TIMESTAMP_NTZ
         FROM (SELECT * FROM ' || P_VIEW || ' WHERE RN = 1 AND REJECT_REASON IS NULL) s
         WHERE t.' || P_KEY || ' = s.BK
           AND t.IS_CURRENT = TRUE
           AND t.ROW_HASH <> s.ROW_HASH
           AND s.VERSION_TS >= t.VERSION_TS';
    v_expired := SQLROWCOUNT;

    -- STEP 5: SCD2 insert - new keys + new versions of changed keys
    EXECUTE IMMEDIATE
        'INSERT INTO ' || P_TARGET || ' (' || P_COLS || ',
             ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
             DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
         SELECT ' || P_COLS || ',
             ROW_HASH, VERSION_TS, VERSION_TS, ''9999-12-31 00:00:00''::TIMESTAMP_NTZ, TRUE,
             DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS,
             ''' || v_ts || '''::TIMESTAMP_NTZ
         FROM ' || P_VIEW || ' s
         WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
           AND NOT EXISTS (SELECT 1 FROM ' || P_TARGET || ' t
                           WHERE t.' || P_KEY || ' = s.BK AND t.IS_CURRENT = TRUE)';
    v_inserted := SQLROWCOUNT;

    -- STEP 6: audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'),
           COUNT_IF(ISSUE_TYPE = 'DUPLICATE'),
           COUNT_IF(ISSUE_TYPE = 'STALE')
      INTO :v_rej, :v_dup, :v_stale
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
     WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, :P_ENTITY, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
           :v_staged, :v_rej, :v_dup, :v_stale, :v_expired, :v_inserted,
           :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted,
           'SUCCESS';

    COMMIT;

    RETURN P_ENTITY || ': staged=' || v_staged || ', rejected=' || v_rej ||
           ', duplicates=' || v_dup || ', stale=' || v_stale ||
           ', expired=' || v_expired || ', inserted=' || v_inserted;

EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, :P_ENTITY, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;








-- ============================================
-- 7. STREAMS ON BRONZE
-- APPEND_ONLY     : Bronze is insert-only (COPY / Snowpipe)
-- SHOW_INITIAL_ROWS: first read returns rows already in Bronze (initial load)
-- ============================================

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_PRODUCTS
    ON TABLE FMCG_DB.BRONZE.BRONZE_PRODUCTS             APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_STORES
    ON TABLE FMCG_DB.BRONZE.BRONZE_STORES               APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_WAREHOUSE
    ON TABLE FMCG_DB.BRONZE.BRONZE_WAREHOUSE            APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS
    ON TABLE FMCG_DB.BRONZE.BRONZE_SALES_ORDERS         APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_INVENTORY_SNAPSHOTS
    ON TABLE FMCG_DB.BRONZE.BRONZE_INVENTORY_SNAPSHOTS  APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_REPLENISHMENT_ORDERS
    ON TABLE FMCG_DB.BRONZE.BRONZE_REPLENISHMENT_ORDERS APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

CREATE OR REPLACE STREAM FMCG_DB.BRONZE.STRM_BRONZE_SALES_EVENTS
    ON TABLE FMCG_DB.BRONZE.BRONZE_SALES_EVENTS         APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE;

SHOW STREAMS IN SCHEMA FMCG_DB.BRONZE;


-- ============================================
-- 8. TASK DAG
--
--   TASK_SLV_PRODUCTS (root, every 5 min, only if any stream has data)
--      |-- TASK_SLV_STORES
--      |-- TASK_SLV_WAREHOUSE
--             |-- (after STORES + WAREHOUSE)
--             |-- TASK_SLV_SALES_ORDERS
--             |-- TASK_SLV_INVENTORY_SNAPSHOTS
--             |-- TASK_SLV_REPLENISHMENT_ORDERS
--             |-- TASK_SLV_SALES_EVENTS
--
-- Dimensions load before facts, so FK checks see the latest dimensions.
-- ============================================

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = '5 MINUTE'
WHEN
       SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_PRODUCTS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_STORES')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_WAREHOUSE')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_INVENTORY_SNAPSHOTS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_REPLENISHMENT_ORDERS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_SALES_EVENTS')
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'PRODUCTS',
    'FMCG_DB.BRONZE.STRM_BRONZE_PRODUCTS',
    'FMCG_DB.SILVER.STG_PRODUCTS_RAW',
    'FMCG_DB.SILVER.V_PREP_PRODUCTS',
    'FMCG_DB.SILVER.SILVER_PRODUCTS',
    'PRODUCT_ID',
    'PRODUCT_ID, PRODUCT_NAME, CATEGORY, SUB_CATEGORY, BRAND, UNIT_COST, LIST_PRICE, SHELF_LIFE_DAYS, PACK_SIZE, ACTIVE_FLAG, SOURCE_UPDATED_TS'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_STORES
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_PRODUCTS
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'STORES',
    'FMCG_DB.BRONZE.STRM_BRONZE_STORES',
    'FMCG_DB.SILVER.STG_STORES_RAW',
    'FMCG_DB.SILVER.V_PREP_STORES',
    'FMCG_DB.SILVER.SILVER_STORES',
    'STORE_ID',
    'STORE_ID, STORE_NAME, CITY, STATE, REGION, STORE_FORMAT, OPENING_DATE, STORAGE_CAPACITY_UNITS, ACTIVE_FLAG, SOURCE_UPDATED_TS'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_PRODUCTS
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'WAREHOUSE',
    'FMCG_DB.BRONZE.STRM_BRONZE_WAREHOUSE',
    'FMCG_DB.SILVER.STG_WAREHOUSE_RAW',
    'FMCG_DB.SILVER.V_PREP_WAREHOUSE',
    'FMCG_DB.SILVER.SILVER_WAREHOUSE',
    'WAREHOUSE_ID',
    'WAREHOUSE_ID, WAREHOUSE_NAME, CITY, STATE, REGION, WAREHOUSE_TYPE, CAPACITY_UNITS, TEMPERATURE_CONTROL_FLAG, ACTIVE_FLAG, SOURCE_UPDATED_TS'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_SALES_ORDERS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'SALES_ORDERS',
    'FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS',
    'FMCG_DB.SILVER.STG_SALES_ORDERS_RAW',
    'FMCG_DB.SILVER.V_PREP_SALES_ORDERS',
    'FMCG_DB.SILVER.SILVER_SALES_ORDERS',
    'ORDER_ID',
    'ORDER_ID, STORE_ID, PRODUCT_ID, ORDER_DATE, QUANTITY_SOLD, UNIT_PRICE, DISCOUNT_AMOUNT, TAX_AMOUNT, NET_AMOUNT, ORDER_STATUS, SALES_CHANNEL, SOURCE_UPDATED_TS'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_INVENTORY_SNAPSHOTS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'INVENTORY_SNAPSHOTS',
    'FMCG_DB.BRONZE.STRM_BRONZE_INVENTORY_SNAPSHOTS',
    'FMCG_DB.SILVER.STG_INVENTORY_SNAPSHOTS_RAW',
    'FMCG_DB.SILVER.V_PREP_INVENTORY_SNAPSHOTS',
    'FMCG_DB.SILVER.SILVER_INVENTORY_SNAPSHOTS',
    'SNAPSHOT_ID',
    'SNAPSHOT_ID, LOCATION_TYPE, LOCATION_ID, PRODUCT_ID, STOCK_STATUS, SNAPSHOT_DATE, SOURCE_UPDATED_TS, ON_HAND_QTY, RESERVED_QTY, AVAILABLE_QTY, REORDER_POINT, SAFETY_STOCK'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_REPLENISHMENT_ORDERS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'REPLENISHMENT_ORDERS',
    'FMCG_DB.BRONZE.STRM_BRONZE_REPLENISHMENT_ORDERS',
    'FMCG_DB.SILVER.STG_REPLENISHMENT_ORDERS_RAW',
    'FMCG_DB.SILVER.V_PREP_REPLENISHMENT_ORDERS',
    'FMCG_DB.SILVER.SILVER_REPLENISHMENT_ORDERS',
    'REPLENISHMENT_ID',
    'REPLENISHMENT_ID, SOURCE_WAREHOUSE_ID, DESTINATION_STORE_ID, PRODUCT_ID, REQUEST_DATE, ALLOCATED_DATE, DISPATCH_DATE, DELIVERED_DATE, REPLENISHMENT_STATUS, PRIORITY_CODE, REQUEST_QTY, ALLOCATED_QTY, DISPATCH_QTY, DELIVERED_QTY, EXPECTED_DELIVERY_DATE, SOURCE_UPDATED_TS'
);

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_SALES_EVENTS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
CALL FMCG_DB.SILVER.SP_SCD2_LOAD(
    'SALES_EVENTS',
    'FMCG_DB.BRONZE.STRM_BRONZE_SALES_EVENTS',
    'FMCG_DB.SILVER.STG_SALES_EVENTS_RAW',
    'FMCG_DB.SILVER.V_PREP_SALES_EVENTS',
    'FMCG_DB.SILVER.SILVER_SALES_EVENTS',
    'EVENT_ID',
    'EVENT_ID, STORE_ID, PRODUCT_ID, EVENT_TIMESTAMP, EVENT_DATE, SALES_CHANNEL, QUANTITY, SELLING_PRICE, PROMOTION_FLAG, PROMOTION_ID, WEATHER_CODE, SOURCE_SYSTEM, TERMINAL_ID, BASKET_SIZE, PAYMENT_MODE'
);

-- Resume children first, root last
ALTER TASK FMCG_DB.SILVER.TASK_SLV_SALES_EVENTS          RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_REPLENISHMENT_ORDERS  RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_INVENTORY_SNAPSHOTS   RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_SALES_ORDERS          RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_WAREHOUSE             RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_STORES                RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS              RESUME;

SHOW TASKS IN SCHEMA FMCG_DB.SILVER;


-- ============================================
-- 9. FIRST RUN (initial load of existing Bronze data)
-- Run the whole DAG once now instead of waiting 5 minutes.
-- ============================================

EXECUTE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS;

-- Watch the run (refresh after ~1 minute)
SELECT NAME, STATE, SCHEDULED_TIME, COMPLETED_TIME, RETURN_VALUE, ERROR_MESSAGE
FROM TABLE(FMCG_DB.INFORMATION_SCHEMA.TASK_HISTORY(
        SCHEDULED_TIME_RANGE_START => DATEADD(HOUR, -1, CURRENT_TIMESTAMP())))
ORDER BY SCHEDULED_TIME DESC;


-- ============================================
-- 10. VALIDATION
-- ============================================

-- 10.1 Load audit / reconciliation per run
--      STAGED = REJECTED + DUPLICATES + STALE + INSERTED + UNCHANGED
SELECT TABLE_NAME, RUN_TS, STAGED, REJECTED, DUPLICATES, STALE,
       EXPIRED, INSERTED, UNCHANGED, STATUS
FROM SILVER_LOAD_AUDIT
ORDER BY RUN_TS DESC;

-- 10.2 Bronze vs Silver current rows
SELECT 'PRODUCTS' AS TABLE_NAME,
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_PRODUCTS)            AS BRONZE_ROWS,
       (SELECT COUNT(*) FROM SILVER_PRODUCTS WHERE IS_CURRENT)          AS SILVER_CURRENT,
       (SELECT COUNT(*) FROM SILVER_PRODUCTS)                           AS SILVER_ALL_VERSIONS
UNION ALL SELECT 'STORES',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_STORES),
       (SELECT COUNT(*) FROM SILVER_STORES WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_STORES)
UNION ALL SELECT 'WAREHOUSE',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_WAREHOUSE),
       (SELECT COUNT(*) FROM SILVER_WAREHOUSE WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_WAREHOUSE)
UNION ALL SELECT 'SALES_ORDERS',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_SALES_ORDERS),
       (SELECT COUNT(*) FROM SILVER_SALES_ORDERS WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_SALES_ORDERS)
UNION ALL SELECT 'INVENTORY_SNAPSHOTS',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_INVENTORY_SNAPSHOTS),
       (SELECT COUNT(*) FROM SILVER_INVENTORY_SNAPSHOTS WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_INVENTORY_SNAPSHOTS)
UNION ALL SELECT 'REPLENISHMENT_ORDERS',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_REPLENISHMENT_ORDERS),
       (SELECT COUNT(*) FROM SILVER_REPLENISHMENT_ORDERS WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_REPLENISHMENT_ORDERS)
UNION ALL SELECT 'SALES_EVENTS',
       (SELECT COUNT(*) FROM FMCG_DB.BRONZE.BRONZE_SALES_EVENTS),
       (SELECT COUNT(*) FROM SILVER_SALES_EVENTS WHERE IS_CURRENT),
       (SELECT COUNT(*) FROM SILVER_SALES_EVENTS);

-- 10.3 SCD2 integrity: must return 0 rows (only one current version per key)
SELECT 'PRODUCTS' AS TBL, PRODUCT_ID AS BK, COUNT(*) FROM SILVER_PRODUCTS WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'STORES', STORE_ID, COUNT(*) FROM SILVER_STORES WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'WAREHOUSE', WAREHOUSE_ID, COUNT(*) FROM SILVER_WAREHOUSE WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'SALES_ORDERS', ORDER_ID, COUNT(*) FROM SILVER_SALES_ORDERS WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'INVENTORY', SNAPSHOT_ID, COUNT(*) FROM SILVER_INVENTORY_SNAPSHOTS WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'REPLENISHMENT', REPLENISHMENT_ID, COUNT(*) FROM SILVER_REPLENISHMENT_ORDERS WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1
UNION ALL SELECT 'SALES_EVENTS', EVENT_ID, COUNT(*) FROM SILVER_SALES_EVENTS WHERE IS_CURRENT GROUP BY 1,2 HAVING COUNT(*) > 1;

-- 10.4 Exceptions by reason
SELECT TABLE_NAME, ISSUE_TYPE, ISSUE_REASON, COUNT(*) AS RECORDS
FROM SILVER_DQ_EXCEPTIONS
GROUP BY TABLE_NAME, ISSUE_TYPE, ISSUE_REASON
ORDER BY TABLE_NAME, RECORDS DESC;


-- ============================================
-- 11. SCD2 + IDEMPOTENCY TEST (demo for evaluation)
-- ============================================

-- 11.1 Pick a product and see its current version
SELECT PRODUCT_ID, LIST_PRICE, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT
FROM SILVER_PRODUCTS
WHERE PRODUCT_ID = (SELECT MIN(PRODUCT_ID) FROM SILVER_PRODUCTS);

-- 11.2 CHANGE TEST: land a new version in Bronze (list price +5, newer timestamp)
INSERT INTO FMCG_DB.BRONZE.BRONZE_PRODUCTS (
    SOURCE_UPDATED_TS, PRODUCT_ID, PRODUCT_NAME, CATEGORY, SUB_CATEGORY, BRAND,
    UNIT_COST, LIST_PRICE, SHELF_LIFE_DAYS, PACK_SIZE, ACTIVE_FLAG,
    SOURCE_FILE, LOAD_TIMESTAMP, BATCH_ID)
SELECT '2030/01/01 00:00:00', PRODUCT_ID, PRODUCT_NAME, CATEGORY, SUB_CATEGORY, BRAND,
       UNIT_COST, TO_VARCHAR(TRY_TO_NUMBER(LIST_PRICE, 18, 2) + 5), SHELF_LIFE_DAYS,
       PACK_SIZE, ACTIVE_FLAG, 'SCD2_TEST', TO_VARCHAR(CURRENT_TIMESTAMP()::TIMESTAMP_NTZ), 'SCD2_TEST'
FROM FMCG_DB.BRONZE.BRONZE_PRODUCTS
WHERE UPPER(TRIM(PRODUCT_ID)) = (SELECT MIN(PRODUCT_ID) FROM SILVER_PRODUCTS)
LIMIT 1;

EXECUTE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS;
-- wait ~1 minute, then: expect 2 rows -> old (IS_CURRENT = FALSE, EFFECTIVE_TO set) + new (IS_CURRENT = TRUE)
SELECT PRODUCT_ID, LIST_PRICE, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT
FROM SILVER_PRODUCTS
WHERE PRODUCT_ID = (SELECT MIN(PRODUCT_ID) FROM SILVER_PRODUCTS)
ORDER BY EFFECTIVE_FROM;

-- 11.3 IDEMPOTENCY TEST: replay the exact same row again
INSERT INTO FMCG_DB.BRONZE.BRONZE_PRODUCTS
SELECT * FROM FMCG_DB.BRONZE.BRONZE_PRODUCTS WHERE SOURCE_FILE = 'SCD2_TEST' LIMIT 1;

EXECUTE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS;
-- wait ~1 minute, then: still 2 versions, latest audit row shows UNCHANGED = 1, INSERTED = 0
SELECT TABLE_NAME, RUN_TS, STAGED, INSERTED, UNCHANGED, STATUS
FROM SILVER_LOAD_AUDIT WHERE TABLE_NAME = 'PRODUCTS' ORDER BY RUN_TS DESC LIMIT 1;


-- ============================================
-- 12. OPERATIONS
-- ============================================

-- Stop the DAG (root first) to save credits after the demo
-- ALTER TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS SUSPEND;

-- Check pending rows in a stream
-- SELECT COUNT(*) FROM FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS;

SHOW TABLES IN SCHEMA FMCG_DB.SILVER;


SELECT * FROM SILVER_LOAD_AUDIT;
SELECT * FROM SILVER_DQ_EXCEPTIONS;
SELECT * FROM SILVER_SALES_ORDERS;

-- ============================================
-- FMCG SILVER LAYER - SEPARATE PROCEDURE PER TABLE
-- 7 STREAMS | 7 PROCEDURES | 7 TASKS
-- ============================================
--
-- CHANGE FROM PREVIOUS VERSION
--   Before : 1 generic procedure SP_SCD2_LOAD(...) with dynamic SQL, called by all 7 tasks
--   Now    : 1 dedicated procedure per table, static SQL, no parameters
--
--   STREAM                               PROCEDURE                               TASK
--   STRM_BRONZE_PRODUCTS             ->  SP_LOAD_SILVER_PRODUCTS             ->  TASK_SLV_PRODUCTS (root)
--   STRM_BRONZE_STORES               ->  SP_LOAD_SILVER_STORES               ->  TASK_SLV_STORES
--   STRM_BRONZE_WAREHOUSE            ->  SP_LOAD_SILVER_WAREHOUSE            ->  TASK_SLV_WAREHOUSE
--   STRM_BRONZE_SALES_ORDERS         ->  SP_LOAD_SILVER_SALES_ORDERS         ->  TASK_SLV_SALES_ORDERS
--   STRM_BRONZE_INVENTORY_SNAPSHOTS  ->  SP_LOAD_SILVER_INVENTORY_SNAPSHOTS  ->  TASK_SLV_INVENTORY_SNAPSHOTS
--   STRM_BRONZE_REPLENISHMENT_ORDERS ->  SP_LOAD_SILVER_REPLENISHMENT_ORDERS ->  TASK_SLV_REPLENISHMENT_ORDERS
--   STRM_BRONZE_SALES_EVENTS         ->  SP_LOAD_SILVER_SALES_EVENTS         ->  TASK_SLV_SALES_EVENTS
--
-- UNCHANGED (do NOT re-run unless you are rebuilding everything)
--   Section 1 helper functions, 2 DQ/audit tables, 3 staging tables,
--   4 Silver SCD2 tables, 5 prep views, 7 streams.
--
-- EVERY PROCEDURE DOES THE SAME 6 STEPS IN ONE TRANSACTION
--   1. Consume its stream into its staging table
--   2. Log REJECT + DUPLICATE rows (from its prep view)
--   3. Log STALE rows (older than current Silver version)
--   4. SCD2 expire  : close current version if attributes changed
--   5. SCD2 insert  : new keys + new versions
--   6. Write SILVER_LOAD_AUDIT, COMMIT
--   On error -> ROLLBACK (stream not consumed, batch retried next run)
--
-- RUN ORDER: STEP 1 -> STEP 4 of this file.
-- Change COMPUTE_WH to your warehouse name.
-- ============================================

USE ROLE ACCOUNTADMIN;
USE DATABASE FMCG_DB;
USE SCHEMA FMCG_DB.SILVER;


-- ============================================
-- STEP 1. SUSPEND THE ROOT TASK (required before changing tasks)
-- ============================================

ALTER TASK IF EXISTS FMCG_DB.SILVER.TASK_SLV_PRODUCTS SUSPEND;


-- ============================================
-- STEP 2. ONE PROCEDURE PER TABLE
-- ============================================


-- --------------------------------------------
-- 2.1 PRODUCTS
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_PRODUCTS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_PRODUCTS_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_PRODUCTS_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_PRODUCTS;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'PRODUCTS: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'PRODUCTS', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate PRODUCT_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_PRODUCTS
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'PRODUCTS', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_PRODUCTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_PRODUCTS t
                  WHERE t.PRODUCT_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_PRODUCTS t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_PRODUCTS
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.PRODUCT_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_PRODUCTS (
        PRODUCT_ID, PRODUCT_NAME, CATEGORY, SUB_CATEGORY, BRAND, UNIT_COST, LIST_PRICE,
        SHELF_LIFE_DAYS, PACK_SIZE, ACTIVE_FLAG, SOURCE_UPDATED_TS,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.PRODUCT_ID, s.PRODUCT_NAME, s.CATEGORY, s.SUB_CATEGORY, s.BRAND, s.UNIT_COST, s.LIST_PRICE,
        s.SHELF_LIFE_DAYS, s.PACK_SIZE, s.ACTIVE_FLAG, s.SOURCE_UPDATED_TS,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_PRODUCTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_PRODUCTS t
                      WHERE t.PRODUCT_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'PRODUCTS', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'PRODUCTS: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'PRODUCTS', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.2 STORES
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_STORES()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_STORES_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_STORES_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_STORES;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'STORES: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'STORES', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate STORE_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_STORES
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'STORES', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_STORES s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_STORES t
                  WHERE t.STORE_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_STORES t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_STORES
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.STORE_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_STORES (
        STORE_ID, STORE_NAME, CITY, STATE, REGION, STORE_FORMAT, OPENING_DATE,
        STORAGE_CAPACITY_UNITS, ACTIVE_FLAG, SOURCE_UPDATED_TS,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.STORE_ID, s.STORE_NAME, s.CITY, s.STATE, s.REGION, s.STORE_FORMAT, s.OPENING_DATE,
        s.STORAGE_CAPACITY_UNITS, s.ACTIVE_FLAG, s.SOURCE_UPDATED_TS,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_STORES s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_STORES t
                      WHERE t.STORE_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'STORES', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'STORES: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'STORES', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.3 WAREHOUSE
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_WAREHOUSE()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_WAREHOUSE_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_WAREHOUSE_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_WAREHOUSE;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'WAREHOUSE: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'WAREHOUSE', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate WAREHOUSE_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_WAREHOUSE
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'WAREHOUSE', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_WAREHOUSE s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_WAREHOUSE t
                  WHERE t.WAREHOUSE_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_WAREHOUSE t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_WAREHOUSE
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.WAREHOUSE_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_WAREHOUSE (
        WAREHOUSE_ID, WAREHOUSE_NAME, CITY, STATE, REGION, WAREHOUSE_TYPE, CAPACITY_UNITS,
        TEMPERATURE_CONTROL_FLAG, ACTIVE_FLAG, SOURCE_UPDATED_TS,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.WAREHOUSE_ID, s.WAREHOUSE_NAME, s.CITY, s.STATE, s.REGION, s.WAREHOUSE_TYPE, s.CAPACITY_UNITS,
        s.TEMPERATURE_CONTROL_FLAG, s.ACTIVE_FLAG, s.SOURCE_UPDATED_TS,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_WAREHOUSE s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_WAREHOUSE t
                      WHERE t.WAREHOUSE_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'WAREHOUSE', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'WAREHOUSE: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'WAREHOUSE', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.4 SALES ORDERS
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_ORDERS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_SALES_ORDERS_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_SALES_ORDERS_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'SALES_ORDERS: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'SALES_ORDERS', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate ORDER_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_SALES_ORDERS
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'SALES_ORDERS', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_SALES_ORDERS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_SALES_ORDERS t
                  WHERE t.ORDER_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_SALES_ORDERS t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_SALES_ORDERS
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.ORDER_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_SALES_ORDERS (
        ORDER_ID, STORE_ID, PRODUCT_ID, ORDER_DATE, QUANTITY_SOLD, UNIT_PRICE, DISCOUNT_AMOUNT,
        TAX_AMOUNT, NET_AMOUNT, ORDER_STATUS, SALES_CHANNEL, SOURCE_UPDATED_TS,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.ORDER_ID, s.STORE_ID, s.PRODUCT_ID, s.ORDER_DATE, s.QUANTITY_SOLD, s.UNIT_PRICE, s.DISCOUNT_AMOUNT,
        s.TAX_AMOUNT, s.NET_AMOUNT, s.ORDER_STATUS, s.SALES_CHANNEL, s.SOURCE_UPDATED_TS,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_SALES_ORDERS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_SALES_ORDERS t
                      WHERE t.ORDER_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'SALES_ORDERS', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'SALES_ORDERS: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'SALES_ORDERS', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.5 INVENTORY SNAPSHOTS
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_INVENTORY_SNAPSHOTS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_INVENTORY_SNAPSHOTS_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_INVENTORY_SNAPSHOTS_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_INVENTORY_SNAPSHOTS;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'INVENTORY_SNAPSHOTS: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'INVENTORY_SNAPSHOTS', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate SNAPSHOT_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_INVENTORY_SNAPSHOTS
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'INVENTORY_SNAPSHOTS', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_INVENTORY_SNAPSHOTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_INVENTORY_SNAPSHOTS t
                  WHERE t.SNAPSHOT_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_INVENTORY_SNAPSHOTS t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_INVENTORY_SNAPSHOTS
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.SNAPSHOT_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_INVENTORY_SNAPSHOTS (
        SNAPSHOT_ID, LOCATION_TYPE, LOCATION_ID, PRODUCT_ID, STOCK_STATUS, SNAPSHOT_DATE,
        SOURCE_UPDATED_TS, ON_HAND_QTY, RESERVED_QTY, AVAILABLE_QTY, REORDER_POINT, SAFETY_STOCK,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.SNAPSHOT_ID, s.LOCATION_TYPE, s.LOCATION_ID, s.PRODUCT_ID, s.STOCK_STATUS, s.SNAPSHOT_DATE,
        s.SOURCE_UPDATED_TS, s.ON_HAND_QTY, s.RESERVED_QTY, s.AVAILABLE_QTY, s.REORDER_POINT, s.SAFETY_STOCK,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_INVENTORY_SNAPSHOTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_INVENTORY_SNAPSHOTS t
                      WHERE t.SNAPSHOT_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'INVENTORY_SNAPSHOTS', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'INVENTORY_SNAPSHOTS: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'INVENTORY_SNAPSHOTS', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.6 REPLENISHMENT ORDERS
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_REPLENISHMENT_ORDERS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_REPLENISHMENT_ORDERS_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_REPLENISHMENT_ORDERS_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_REPLENISHMENT_ORDERS;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'REPLENISHMENT_ORDERS: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'REPLENISHMENT_ORDERS', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate REPLENISHMENT_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_REPLENISHMENT_ORDERS
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'REPLENISHMENT_ORDERS', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_REPLENISHMENT_ORDERS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_REPLENISHMENT_ORDERS t
                  WHERE t.REPLENISHMENT_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_REPLENISHMENT_ORDERS t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_REPLENISHMENT_ORDERS
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.REPLENISHMENT_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_REPLENISHMENT_ORDERS (
        REPLENISHMENT_ID, SOURCE_WAREHOUSE_ID, DESTINATION_STORE_ID, PRODUCT_ID, REQUEST_DATE,
        ALLOCATED_DATE, DISPATCH_DATE, DELIVERED_DATE, REPLENISHMENT_STATUS, PRIORITY_CODE,
        REQUEST_QTY, ALLOCATED_QTY, DISPATCH_QTY, DELIVERED_QTY, EXPECTED_DELIVERY_DATE, SOURCE_UPDATED_TS,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.REPLENISHMENT_ID, s.SOURCE_WAREHOUSE_ID, s.DESTINATION_STORE_ID, s.PRODUCT_ID, s.REQUEST_DATE,
        s.ALLOCATED_DATE, s.DISPATCH_DATE, s.DELIVERED_DATE, s.REPLENISHMENT_STATUS, s.PRIORITY_CODE,
        s.REQUEST_QTY, s.ALLOCATED_QTY, s.DISPATCH_QTY, s.DELIVERED_QTY, s.EXPECTED_DELIVERY_DATE, s.SOURCE_UPDATED_TS,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_REPLENISHMENT_ORDERS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_REPLENISHMENT_ORDERS t
                      WHERE t.REPLENISHMENT_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'REPLENISHMENT_ORDERS', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'REPLENISHMENT_ORDERS: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'REPLENISHMENT_ORDERS', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;


-- --------------------------------------------
-- 2.7 SALES EVENTS
-- --------------------------------------------
CREATE OR REPLACE PROCEDURE FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_EVENTS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id    VARCHAR;
    v_load_ts   TIMESTAMP_NTZ;
    v_staged    INTEGER DEFAULT 0;
    v_rej       INTEGER DEFAULT 0;
    v_dup       INTEGER DEFAULT 0;
    v_stale     INTEGER DEFAULT 0;
    v_expired   INTEGER DEFAULT 0;
    v_inserted  INTEGER DEFAULT 0;
    v_err       VARCHAR;
BEGIN
    v_run_id  := UUID_STRING();
    v_load_ts := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

    BEGIN TRANSACTION;

    -- 1. Consume stream
    DELETE FROM FMCG_DB.SILVER.STG_SALES_EVENTS_RAW;
    INSERT INTO FMCG_DB.SILVER.STG_SALES_EVENTS_RAW
        SELECT * EXCLUDE (METADATA$ACTION, METADATA$ISUPDATE, METADATA$ROW_ID)
        FROM FMCG_DB.BRONZE.STRM_BRONZE_SALES_EVENTS;
    v_staged := SQLROWCOUNT;

    IF (v_staged = 0) THEN
        COMMIT;
        RETURN 'SALES_EVENTS: no new rows';
    END IF;

    -- 2. Rejects + duplicates
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'SALES_EVENTS', BK,
           IFF(REJECT_REASON IS NOT NULL, 'REJECT', 'DUPLICATE'),
           COALESCE(REJECT_REASON, 'Duplicate EVENT_ID in batch - older version'),
           OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_SALES_EVENTS
    WHERE RN > 1 OR REJECT_REASON IS NOT NULL;

    -- 3. Stale rows
    INSERT INTO FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS
        (RUN_ID, TABLE_NAME, RECORD_KEY, ISSUE_TYPE, ISSUE_REASON, RECORD_DATA)
    SELECT :v_run_id, 'SALES_EVENTS', s.BK, 'STALE',
           'Older than current Silver version - ignored', OBJECT_CONSTRUCT(*)
    FROM FMCG_DB.SILVER.V_PREP_SALES_EVENTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_SALES_EVENTS t
                  WHERE t.EVENT_ID = s.BK AND t.IS_CURRENT = TRUE
                    AND t.ROW_HASH <> s.ROW_HASH AND t.VERSION_TS > s.VERSION_TS);
    v_stale := SQLROWCOUNT;

    -- 4. SCD2 expire
    UPDATE FMCG_DB.SILVER.SILVER_SALES_EVENTS t
    SET IS_CURRENT = FALSE, EFFECTIVE_TO = s.VERSION_TS, SILVER_UPDATED_TS = :v_load_ts
    FROM (SELECT BK, ROW_HASH, VERSION_TS FROM FMCG_DB.SILVER.V_PREP_SALES_EVENTS
          WHERE RN = 1 AND REJECT_REASON IS NULL) s
    WHERE t.EVENT_ID = s.BK AND t.IS_CURRENT = TRUE
      AND t.ROW_HASH <> s.ROW_HASH AND s.VERSION_TS >= t.VERSION_TS;
    v_expired := SQLROWCOUNT;

    -- 5. SCD2 insert
    INSERT INTO FMCG_DB.SILVER.SILVER_SALES_EVENTS (
        EVENT_ID, STORE_ID, PRODUCT_ID, EVENT_TIMESTAMP, EVENT_DATE, SALES_CHANNEL, QUANTITY,
        SELLING_PRICE, PROMOTION_FLAG, PROMOTION_ID, WEATHER_CODE, SOURCE_SYSTEM, TERMINAL_ID,
        BASKET_SIZE, PAYMENT_MODE,
        ROW_HASH, VERSION_TS, EFFECTIVE_FROM, EFFECTIVE_TO, IS_CURRENT,
        DQ_STATUS, DQ_REASON, SOURCE_FILE, BATCH_ID, BRONZE_LOAD_TS, SILVER_LOAD_TS)
    SELECT
        s.EVENT_ID, s.STORE_ID, s.PRODUCT_ID, s.EVENT_TIMESTAMP, s.EVENT_DATE, s.SALES_CHANNEL, s.QUANTITY,
        s.SELLING_PRICE, s.PROMOTION_FLAG, s.PROMOTION_ID, s.WEATHER_CODE, s.SOURCE_SYSTEM, s.TERMINAL_ID,
        s.BASKET_SIZE, s.PAYMENT_MODE,
        s.ROW_HASH, s.VERSION_TS, s.VERSION_TS, '9999-12-31 00:00:00'::TIMESTAMP_NTZ, TRUE,
        s.DQ_STATUS, s.DQ_REASON, s.SOURCE_FILE, s.BATCH_ID, s.BRONZE_LOAD_TS, :v_load_ts
    FROM FMCG_DB.SILVER.V_PREP_SALES_EVENTS s
    WHERE s.RN = 1 AND s.REJECT_REASON IS NULL
      AND NOT EXISTS (SELECT 1 FROM FMCG_DB.SILVER.SILVER_SALES_EVENTS t
                      WHERE t.EVENT_ID = s.BK AND t.IS_CURRENT = TRUE);
    v_inserted := SQLROWCOUNT;

    -- 6. Audit
    SELECT COUNT_IF(ISSUE_TYPE = 'REJECT'), COUNT_IF(ISSUE_TYPE = 'DUPLICATE')
      INTO :v_rej, :v_dup
      FROM FMCG_DB.SILVER.SILVER_DQ_EXCEPTIONS WHERE RUN_ID = :v_run_id;

    INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT
    SELECT :v_run_id, 'SALES_EVENTS', :v_load_ts, :v_staged, :v_rej, :v_dup, :v_stale,
           :v_expired, :v_inserted, :v_staged - :v_rej - :v_dup - :v_stale - :v_inserted, 'SUCCESS';

    COMMIT;
    RETURN 'SALES_EVENTS: staged=' || v_staged || ', rejected=' || v_rej || ', duplicates=' || v_dup ||
           ', stale=' || v_stale || ', expired=' || v_expired || ', inserted=' || v_inserted;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        v_err := SQLERRM;
        INSERT INTO FMCG_DB.SILVER.SILVER_LOAD_AUDIT (RUN_ID, TABLE_NAME, RUN_TS, STATUS)
        SELECT :v_run_id, 'SALES_EVENTS', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'FAILED: ' || :v_err;
        RAISE;
END;
$$;

SHOW PROCEDURES LIKE 'SP_LOAD_SILVER_%' IN SCHEMA FMCG_DB.SILVER;


-- ============================================
-- STEP 3. TASKS - EACH TASK CALLS ITS OWN PROCEDURE
--
--   TASK_SLV_PRODUCTS (root, every 5 min, only if any stream has data)
--      |-- TASK_SLV_STORES
--      |-- TASK_SLV_WAREHOUSE
--             |-- (after STORES + WAREHOUSE)
--             |-- TASK_SLV_SALES_ORDERS
--             |-- TASK_SLV_INVENTORY_SNAPSHOTS
--             |-- TASK_SLV_REPLENISHMENT_ORDERS
--             |-- TASK_SLV_SALES_EVENTS
-- ============================================

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = '5 MINUTE'
WHEN
       SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_PRODUCTS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_STORES')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_WAREHOUSE')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_SALES_ORDERS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_INVENTORY_SNAPSHOTS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_REPLENISHMENT_ORDERS')
    OR SYSTEM$STREAM_HAS_DATA('FMCG_DB.BRONZE.STRM_BRONZE_SALES_EVENTS')
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_PRODUCTS();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_STORES
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_PRODUCTS
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_STORES();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_PRODUCTS
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_WAREHOUSE();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_SALES_ORDERS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_ORDERS();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_INVENTORY_SNAPSHOTS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_INVENTORY_SNAPSHOTS();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_REPLENISHMENT_ORDERS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_REPLENISHMENT_ORDERS();

CREATE OR REPLACE TASK FMCG_DB.SILVER.TASK_SLV_SALES_EVENTS
    WAREHOUSE = COMPUTE_WH
    AFTER FMCG_DB.SILVER.TASK_SLV_STORES, FMCG_DB.SILVER.TASK_SLV_WAREHOUSE
AS
    CALL FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_EVENTS();

-- Resume children first, root last
ALTER TASK FMCG_DB.SILVER.TASK_SLV_SALES_EVENTS          RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_REPLENISHMENT_ORDERS  RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_INVENTORY_SNAPSHOTS   RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_SALES_ORDERS          RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_WAREHOUSE             RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_STORES                RESUME;
ALTER TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS              RESUME;

SHOW TASKS IN SCHEMA FMCG_DB.SILVER;

-- Old generic procedure is no longer used
DROP PROCEDURE IF EXISTS FMCG_DB.SILVER.SP_SCD2_LOAD(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR);


-- ============================================
-- STEP 4. RUN + VERIFY
-- ============================================

-- Option A: run the whole DAG now
EXECUTE TASK FMCG_DB.SILVER.TASK_SLV_PRODUCTS;

-- Option B: test one table on its own (dimensions first, then facts)
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_PRODUCTS();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_STORES();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_WAREHOUSE();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_ORDERS();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_INVENTORY_SNAPSHOTS();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_REPLENISHMENT_ORDERS();
-- CALL FMCG_DB.SILVER.SP_LOAD_SILVER_SALES_EVENTS();

-- Task run results (RETURN_VALUE shows each procedure's summary)
SELECT NAME, STATE, SCHEDULED_TIME, COMPLETED_TIME, RETURN_VALUE, ERROR_MESSAGE
FROM TABLE(FMCG_DB.INFORMATION_SCHEMA.TASK_HISTORY(
        SCHEDULED_TIME_RANGE_START => DATEADD(HOUR, -1, CURRENT_TIMESTAMP())))
ORDER BY SCHEDULED_TIME DESC;

-- Per-table load audit
SELECT TABLE_NAME, RUN_TS, STAGED, REJECTED, DUPLICATES, STALE, EXPIRED, INSERTED, UNCHANGED, STATUS
FROM FMCG_DB.SILVER.SILVER_LOAD_AUDIT
ORDER BY RUN_TS DESC;
